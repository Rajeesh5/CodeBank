#include "FiniteMachine.h"
#include "EvenState.h"
#include "OddState.h"

#include<iostream>


FiniteMachine::FiniteMachine( char *tmp) {
	str = tmp;
	index = 0;
	state = nullptr;
}

FiniteMachine::~FiniteMachine() {
	delete state;
}

void FiniteMachine::setState(FiniteState *stat) {
	
	if (state == nullptr) {
		std::cout << "Moving state : ^ to " << stat->getName() << "\n";
	}
	else std::cout << "Moving state :" << state->getName() << " to " << stat->getName() << "\n";

	delete state;
	state = stat;
}

bool FiniteMachine::getAccepted() {
	
	std::string s = "Even";
	if (s == state->getName()) {
		return true;
	}
	else return false;
	


}

void FiniteMachine::startProcessing() {

	FiniteState *fs;
	short len = strlen(str);
	while (len > index) {
		if (index % 2 == 0) {
			fs = new OddState("Odd");
			index++;
			fs->odd();
		}
		else {
			fs = new EvenState("Even");
			index++;
			fs->even();
		}
		setState(fs);
	}

}