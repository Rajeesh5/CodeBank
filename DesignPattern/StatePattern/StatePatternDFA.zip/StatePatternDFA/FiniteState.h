#pragma once
#include<string>

class FiniteState
{
public:
	virtual void even() = 0;
	virtual void odd() = 0;
	virtual std::string getName() = 0;
protected:
	std::string name;

};
