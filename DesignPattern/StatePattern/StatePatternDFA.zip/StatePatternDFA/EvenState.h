#pragma once

#include "FiniteState.h"

class EvenState:public FiniteState
{
public:
	EvenState(std::string stateVal);
	void even();
	void odd();
	std::string getName();

private:
	 
};

