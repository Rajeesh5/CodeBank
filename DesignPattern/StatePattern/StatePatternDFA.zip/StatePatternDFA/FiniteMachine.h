#pragma once
#include "FiniteState.h"

class FiniteMachine
{
public:
	FiniteMachine(char *);
	~FiniteMachine();

	void setState(FiniteState*);
	bool getAccepted();
	void startProcessing();
	
private:
	FiniteState *state;
	char *str;
	short index;
};

