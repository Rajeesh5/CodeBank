#include "EvenState.h"
#include<iostream>

EvenState::EvenState(std::string stateVal) {
	name = stateVal;
}

void EvenState::even() {
	std::cout << "Machine is in even state, ";
}

void EvenState::odd() {
	std::cout << "Invalid state transition\n";
}

std::string EvenState::getName() {
	return name;
}