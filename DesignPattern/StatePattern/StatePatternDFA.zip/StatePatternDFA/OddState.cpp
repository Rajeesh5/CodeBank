#include "OddState.h"
#include<iostream>

OddState::OddState(std::string stateVal) {
	name = stateVal;
}

void OddState::even() {
	std::cout << "Invalid state transition\n";
}

void OddState::odd() {
	std::cout << "Machine is in odd state, ";
}

std::string OddState::getName() {
	return name;
}