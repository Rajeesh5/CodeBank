#include "FiniteMachine.h"

#include<iostream>

void main() {

	FiniteMachine machine("aaaaaaaa");
	machine.startProcessing();

	if (machine.getAccepted()) {
		std::cout << "String is even length\n";
	}

	getchar();
}